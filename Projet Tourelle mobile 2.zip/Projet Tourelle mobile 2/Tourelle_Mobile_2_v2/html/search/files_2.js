var searchData=
[
  ['globalparams_2eh',['GlobalParams.h',['../_global_params_8h.html',1,'']]],
  ['globalparams_2einc',['GlobalParams.inc',['../_global_params_8inc.html',1,'']]]
];
