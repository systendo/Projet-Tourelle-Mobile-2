var searchData=
[
  ['m_5fx_5frot_5fanti_5fhor',['M_X_Rot_Anti_Hor',['../motor__functions_8c.html#a8ec0d03635d4e2257babad5da3597ba8',1,'M_X_Rot_Anti_Hor(int *pulsewidth_X):&#160;motor_functions.c'],['../_motor___functions_8h.html#a2a97651f20614a3bb457bb13a4c157e6',1,'M_X_Rot_Anti_Hor(int *):&#160;motor_functions.c']]],
  ['m_5fx_5frot_5fhor',['M_X_Rot_Hor',['../motor__functions_8c.html#abb733a2fb27369562ec27bb637ea4b53',1,'M_X_Rot_Hor(int *pulsewidth_X):&#160;motor_functions.c'],['../_motor___functions_8h.html#aa8c614104927389cb75a74ba84dda474',1,'M_X_Rot_Hor(int *):&#160;motor_functions.c']]],
  ['m_5fz_5frot_5fanti_5fhor',['M_Z_Rot_Anti_Hor',['../motor__functions_8c.html#ad9274ba07b9e3eee39be9c684e41a72f',1,'M_Z_Rot_Anti_Hor(int *pulsewidth_Z, int i):&#160;motor_functions.c'],['../_motor___functions_8h.html#a366579aa0b68b3ff301db5333f0c0d9e',1,'M_Z_Rot_Anti_Hor(int *, int):&#160;motor_functions.c']]],
  ['m_5fz_5frot_5fhor',['M_Z_Rot_Hor',['../motor__functions_8c.html#a80e2e78d865ad88e4649c1717cf4d932',1,'M_Z_Rot_Hor(int *pulsewidth_Z, int i):&#160;motor_functions.c'],['../_motor___functions_8h.html#a2cf6add168394582848363bcf72768dd',1,'M_Z_Rot_Hor(int *, int):&#160;motor_functions.c']]],
  ['main',['main',['../main_8c.html#a6288eba0f8e8ad3ab1544ad731eb7667',1,'main.c']]],
  ['motor_5fbalay',['Motor_Balay',['../motor__functions_8c.html#aafd79e0591bbf9173e4c9e2beac2e947',1,'Motor_Balay(int *a, int *pulsewidth_Z, int *pulsewidth_X, int i):&#160;motor_functions.c'],['../_motor___functions_8h.html#ae39756877e2b6ed4226af05972e3f2b4',1,'Motor_Balay(int *, int *, int *, int):&#160;motor_functions.c']]]
];
