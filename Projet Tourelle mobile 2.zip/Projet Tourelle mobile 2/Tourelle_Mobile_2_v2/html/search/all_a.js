var searchData=
[
  ['op_5famp_5fbias',['OP_AMP_BIAS',['../_global_params_8h.html#a56b699126f0de8ee634c5b3684602bf8',1,'GlobalParams.h']]],
  ['op_5famp_5fbias_5fjust',['OP_AMP_BIAS_JUST',['../_global_params_8h.html#a25d8832f059d6a83d29ed70d71550065',1,'GlobalParams.h']]],
  ['op_5famp_5fbias_5fmask',['OP_AMP_BIAS_MASK',['../_global_params_8h.html#a3ac54d3fd1181622b8088a5053c40f93',1,'GlobalParams.h']]]
];
